﻿// Start dimmer
         let colornumber = 1
        let totalcolors = 5


        function dimmer() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }



             //hmUI.showToast({text: "color " + parseInt(colornumber) });
              normal_image_img.setProperty(hmUI.prop.SRC, "Lv" + parseInt(colornumber-1) + ".png");
                           
        }