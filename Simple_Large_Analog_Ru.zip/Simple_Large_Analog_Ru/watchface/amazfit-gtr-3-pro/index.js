try{(()=>{const e=__$$hmAppManager$$__.currentApp;const n=e.current,{px:g}=(new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,n)),e.__globals__),p=Logger.getLogger("watchface6");n.module=DeviceRuntimeCore.WatchFace({init_view(){hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG,{edit_id:1,x:0,y:0,bg_config:[{id:1,path:"4.png",preview:"5.png"},{id:2,path:"6.png",preview:"7.png"},{id:3,path:"8.png",preview:"9.png"},{id:4,path:"10.png",preview:"11.png"}],count:4,default_id:1,fg:"3.png",tips_x:0,tips_y:0,tips_bg:"2.png",show_level:hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT}),hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,src:"12.png",show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.IMG_DATE,{month_startX:200,month_startY:100,month_sc_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],month_tc_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],month_en_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],month_align:hmUI.align.LEFT,month_zero:0,month_follow:0,month_space:0,month_is_character:!1,day_startX:135,day_startY:100,day_sc_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],day_tc_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],day_en_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],day_align:hmUI.align.RIGHT,day_zero:0,day_follow:0,day_space:0,day_is_character:!1,enable:!1,show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.IMG,{x:180,y:100,w:15,h:20,src:"23.png",show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:249,y:96,week_en:["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],week_tc:["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],week_sc:["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:116,y:218,type:hmUI.data_type.BATTERY,font_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],align_h:hmUI.align.LEFT,h_space:0,show_level:hmUI.show_level.ONLY_NORMAL,padding:!1,isCharacter:!1}),

hmUI.createWidget(hmUI.widget.IMG,{x:123,y:166,src:"31.png",show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:301,y:218,type:hmUI.data_type.HEART,font_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],align_h:hmUI.align.RIGHT,h_space:0,show_level:hmUI.show_level.ONLY_NORMAL,invalid_image:"32.png",padding:!1,isCharacter:!1}),

hmUI.createWidget(hmUI.widget.IMG,{x:314,y:181,src:"33.png",show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:185,y:344,type:hmUI.data_type.STEP,font_array:["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],align_h:hmUI.align.CENTER_H,h_space:0,show_level:hmUI.show_level.ONLY_NORMAL,padding:!1,isCharacter:!1}),

hmUI.createWidget(hmUI.widget.IMG,{x:223,y:319,src:"34.png",show_level:hmUI.show_level.ONLY_NORMAL}),

hmUI.createWidget(hmUI.widget.TIME_POINTER,{hour_centerX:233,hour_centerY:233,hour_posX:90,hour_posY:240,hour_path:"35.png",hour_cover_x:0,hour_cover_y:0,minute_centerX:233,minute_centerY:233,minute_posX:90,minute_posY:240,minute_path:"36.png",minute_cover_x:0,minute_cover_y:0,second_centerX:233,second_centerY:233,second_posX:40,second_posY:240,second_path:"37.png",second_cover_x:0,second_cover_y:0,enable:!1,show_level:hmUI.show_level.ONLY_NORMAL}),
 
                // 01 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 298,
                  y: 40,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'StopWatchScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 02 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 370,
                  y: 110,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'CountdownAppScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 03 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 400,
                  y: 204,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'SportListScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                });
                // 04 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 370,
                  y: 300,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'SportRecordListScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 05 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 298,
                  y: 367,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'FlashLightScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 06 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 205,
                  y: 403,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'Settings_homeScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 07 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 110,
                  y: 365,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'AlarmInfoScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 08 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 45,
                  y: 300,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'Sleep_HomeScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 09 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 8,
                  y: 204,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'heart_app_Screen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 10 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 40,
                  y: 110,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'activityAppScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 11 Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 110,
                  y: 40,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'BioChargeHomeScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // 12 Click Widget "Normal"
                 hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 205,
                  y: 4,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'AppListScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // weather Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 150,
                  y: 110,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'WeatherScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // battery Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 120,
                  y: 170,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'Settings_batteryManagerScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // bluetooth Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 205,
                  y: 330,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'FindPhoneScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // week Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 235,
                  y: 100,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'ScheduleCalScreen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }), 
                
                 // heart Click Widget "Normal"
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 300,
                  y: 160,
                  w: 60,
                  h: 60,
                  text: '',
                press_src: 'trasparente.png',
                normal_src: 'trasparente.png',
                click_func: () => {
                hmApp.startApp({ url: 'heart_app_Screen', native: true })
                			  },
                  show_level: hmUI.show_level.ONLY_NORMAL
                }),
                
hmUI.createWidget(hmUI.widget.IMG,{x:25,y:24,src:"38.png",show_level:hmUI.show_level.ONLY_AOD}),hmUI.createWidget(hmUI.widget.TIME_POINTER,{hour_centerX:233,hour_centerY:233,hour_posX:90,hour_posY:240,hour_path:"39.png",hour_cover_x:0,hour_cover_y:0,minute_centerX:233,minute_centerY:233,minute_posX:90,minute_posY:240,minute_path:"40.png",minute_cover_x:0,minute_cover_y:0,enable:!1,show_level:hmUI.show_level.ONLY_AOD}),hmUI.createWidget(hmUI.widget.IMG,{x:193,y:196,src:"41.png",show_level:hmUI.show_level.ONLY_AOD})},onInit(){p.log("index page.js on init invoke")},build(){this.init_view(),p.log("index page.js on ready invoke")},onDestroy(){p.log("index page.js on destroy invoke")}})})()}catch(e){console.log("Mini Program Error",e),e&&e.stack&&e.stack.split(/\n/).forEach((e=>console.log("error stack",e)))}