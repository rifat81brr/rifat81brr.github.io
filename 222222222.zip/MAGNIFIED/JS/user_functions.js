﻿//добавляем вибрацию (и добавить строку конце)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 28
           vibrate.start()
        }
        
        // В конце меняем 
//            onDestroy() {
//                logger.log('index page.js on destroy invoke');
//          },		

//на 		

// В конце меняем 
//            onDestroy() {
//                logger.log('index page.js on destroy invoke');
//		          vibrate && vibrate.stop();
//          },

		let colorIndex = 0		// текущий индекс цвета
        const colorNum = 8		// всего цветов
		const colorsArr = [0xBBBBBB, 0xFF7A00, 0xFF0300, 0xFF00FB, 0x52AEE8, 0x00F9EB, 0x6BD089, 0xFFE127]	// массив цветов
		//!!!!!!! надо здесь задать нужные цвета в формате 0xRRGGBB

		function toggleColor() {
			
			colorIndex = (colorIndex + 1) % colorNum;		// увеличиваем индекс на 1 по кругу от 0 до colorNum-1
															// т.е. индекс меняется от 0 до 7

			hmUI.showToast({text: `Цвет ${colorIndex + 1}`});	// выводим сообщение "Цвет 1 ... Цвет 7"

            normal_day_text_font.setProperty(hmUI.prop.COLOR, colorsArr[colorIndex]);
            normal_dow_text_font.setProperty(hmUI.prop.COLOR, colorsArr[colorIndex]);
            normal_month_name_font.setProperty(hmUI.prop.COLOR, colorsArr[colorIndex]);
            normal_time_hour_min_text_font.setProperty(hmUI.prop.COLOR, colorsArr[colorIndex]);
            normal_time_second_text_font.setProperty(hmUI.prop.COLOR, colorsArr[colorIndex]);
            normal_battery_linear_scale.setProperty(hmUI.prop.COLOR, colorsArr[colorIndex]);

            normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 54,
              y: 97,
              w: 70,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Alumni_Sans_reg.ttf',
              color: colorsArr[colorIndex],
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
            });

            normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 63,
              y: 329,
              w: 100,
              h: 60,
              text_size: 55,
              char_space: 0,
              font: 'fonts/Alumni_Sans_reg.ttf',
              color: colorsArr[colorIndex],
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
            });

            normal_floor_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 241,
              y: 421,
              w: 60,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Alumni_Sans_reg.ttf',
              color: colorsArr[colorIndex],
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.FLOOR,
            });

            normal_distance_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 256,
              y: 384,
              w: 90,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Alumni_Sans_reg.ttf',
              color: colorsArr[colorIndex],
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
            });

            normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
              x: 177,
              y: 417,
              w: 80,
              h: 60,
              text_size: 55,
              char_space: 0,
              font: 'fonts/Alumni_Sans_reg.ttf',
              color: colorsArr[colorIndex],
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
            });

            normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 136,
              y: 375,
              w: 120,
              h: 60,
              text_size: 55,
              char_space: 0,
              font: 'fonts/Alumni_Sans_reg.ttf',
              color: colorsArr[colorIndex],
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
            });

        }