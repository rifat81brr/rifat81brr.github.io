﻿const deviceInfo1 = hmSetting.getDeviceInfo();
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfo1.width / 480 * 12,
              y: deviceInfo1.height / 480 * 232,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ALL,

            });
check24h()