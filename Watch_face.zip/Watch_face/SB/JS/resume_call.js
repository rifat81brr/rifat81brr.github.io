﻿let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
let value_str = value == 0 ? "--" : value + " мм.рт.ст.";
text_pressere.setProperty(hmUI.prop.TEXT, value_str);

// если нужно отслеживать изменение давления
let pressere_changes_str = "Давление не меняется";
let pressere_changes = changesPressure(pressure_array);
if(pressere_changes < 0) pressere_changes_str = "Давление падает";
if(pressere_changes > 0) pressere_changes_str = "Давление растет";
text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);